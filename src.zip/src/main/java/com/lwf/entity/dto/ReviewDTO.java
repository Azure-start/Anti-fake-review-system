package com.lwf.entity.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
@Data
public class ReviewDTO {
    private Long productId;

    @Min(value = 1, message = "评分不能小于1")
    @Max(value = 5, message = "评分不能大于5")
    private Integer rating;

    @NotBlank(message = "评价内容不能为空")
    private String content;

    private String ipfsCid;
    private String images;
}