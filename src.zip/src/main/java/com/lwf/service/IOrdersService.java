package com.lwf.service;
import com.baomidou.mybatisplus.extension.service.IService;
import com.lwf.entity.Orders;
import com.lwf.entity.dto.OrderDTO;

import java.util.Map;

public interface IOrdersService extends IService<Orders> {
    Map<String, Object> createOrder(OrderDTO orderDTO);
    Map<String, Object> getUserOrders(String userAddress, Integer page, Integer pageSize);
    Map<String, Object> getMerchantOrders(Long merchantId, Integer page, Integer pageSize);
    Map<String, Object> updateOrderStatus(String orderId, String status);
    Map<String, Object> confirmReceipt(String orderId, String userAddress);
    Orders getOrderByTxHash(String txHash);
}