package com.lwf.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lwf.entity.Products;
import com.lwf.entity.Users;
import com.lwf.entity.dto.ProductQueryDTO;
import com.lwf.mapper.ProductsMapper;
import com.lwf.service.IProductsService;
import com.lwf.service.IUsersService;
import com.lwf.utils.BusinessException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Service
public class ProductsServiceImpl extends ServiceImpl<ProductsMapper, Products> implements IProductsService {

    @Autowired
    private IUsersService usersService;

    @Override
    public Map<String, Object> getProductList(ProductQueryDTO query) {
        Map<String, Object> result = new HashMap<>();

        Page<Products> pageInfo = new Page<>(query.getPage(), query.getPageSize());
        QueryWrapper<Products> queryWrapper = new QueryWrapper<>();

        // 只查询已审核的商品
        queryWrapper.eq("status", "approved");

        if (StringUtils.hasText(query.getKeyword())) {
            queryWrapper.like("name", query.getKeyword())
                    .or()
                    .like("description", query.getKeyword());
        }

        // 排序
        if ("price".equals(query.getSortBy())) {
            if ("asc".equals(query.getSortOrder())) {
                queryWrapper.orderByAsc("price");
            } else {
                queryWrapper.orderByDesc("price");
            }
        } else {
            queryWrapper.orderByDesc("created_at");
        }

        Page<Products> productPage = this.page(pageInfo, queryWrapper);

        result.put("list", productPage.getRecords());
        result.put("total", productPage.getTotal());
        result.put("code", 0);

        return result;
    }

    @Override
    public Products getProductDetail(Long productId) {
        Products product = this.getById(productId);
        if (product == null) {
            throw new BusinessException("商品不存在");
        }
        return product;
    }

    @Override
    public Map<String, Object> createProduct(Products product) {
        Map<String, Object> result = new HashMap<>();

        // 验证商家身份
        Users merchant = usersService.getById(product.getMerchantId());
        if (merchant == null || !"merchant".equals(merchant.getRole()) ||
                !"approved".equals(merchant.getShopStatus())) {
            throw new BusinessException("商家身份未验证或未通过审核");
        }

        product.setMerchantAddress(merchant.getAddress());
        product.setStatus("pending"); // 新商品需要审核
        product.setSales(0);
        product.setRating(BigDecimal.ZERO);

        boolean saved = this.save(product);

        if (saved) {
            result.put("code", 0);
            result.put("id", product.getId());
            result.put("status", "pending");
            result.put("message", "商品已提交，等待审核");
        } else {
            throw new BusinessException("商品创建失败");
        }

        return result;
    }

    @Override
    public Map<String, Object> getMerchantProducts(String merchantAddress, Integer page, Integer pageSize) {
        Map<String, Object> result = new HashMap<>();

        Page<Products> pageInfo = new Page<>(page, pageSize);
        QueryWrapper<Products> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("merchant_address", merchantAddress)
                .orderByDesc("created_at");

        Page<Products> productPage = this.page(pageInfo, queryWrapper);

        result.put("list", productPage.getRecords());
        result.put("total", productPage.getTotal());
        result.put("page", page);
        result.put("pageSize", pageSize);
        result.put("code", 0);

        return result;
    }

    @Override
    public Map<String, Object> getPendingProducts(Integer page, Integer pageSize) {
        Map<String, Object> result = new HashMap<>();

        Page<Products> pageInfo = new Page<>(page, pageSize);
        QueryWrapper<Products> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("status", "pending")
                .orderByDesc("created_at");

        Page<Products> productPage = this.page(pageInfo, queryWrapper);

        result.put("list", productPage.getRecords());
        result.put("total", productPage.getTotal());
        result.put("page", page);
        result.put("pageSize", pageSize);
        result.put("code", 0);

        return result;
    }

    @Override
    public Map<String, Object> auditProduct(Long productId, String action) {
        Map<String, Object> result = new HashMap<>();

        Products product = this.getById(productId);
        if (product == null) {
            throw new BusinessException("商品不存在");
        }

        if ("approve".equals(action)) {
            product.setStatus("approved");
            result.put("message", "商品已上架");
        } else if ("reject".equals(action)) {
            product.setStatus("rejected");
            result.put("message", "商品已拒绝");
        } else {
            throw new BusinessException("无效的操作类型");
        }

        this.updateById(product);

        result.put("code", 0);
        result.put("id", productId);
        result.put("status", product.getStatus());
        return result;
    }

    @Override
    public Map<String, Object> updateProductStatus(Long productId, String status) {
        Map<String, Object> result = new HashMap<>();

        Products product = this.getById(productId);
        if (product == null) {
            throw new BusinessException("商品不存在");
        }

        product.setStatus(status);
        this.updateById(product);

        result.put("code", 0);
        result.put("id", productId);
        result.put("status", status);
        return result;
    }
}