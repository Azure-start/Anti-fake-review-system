package com.lwf.controller;

import com.lwf.entity.Products;
import com.lwf.entity.dto.ProductQueryDTO;
import com.lwf.entity.dto.ReviewDTO;
import com.lwf.service.IProductsService;
import com.lwf.service.IReviewsService;
import com.lwf.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class ProductsController {

    @Autowired
    private IProductsService productsService;

    @Autowired
    private IReviewsService reviewsService;

    @GetMapping("/products")
    public Result<Map<String, Object>> getProductList(ProductQueryDTO query) {
        try {
            Map<String, Object> result = productsService.getProductList(query);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/products/{productId}")
    public Result<Products> getProductDetail(@PathVariable Long productId) {
        try {
            Products product = productsService.getProductDetail(productId);
            return Result.success(product);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/products/{productId}/reviews")
    public Result<Map<String, Object>> getProductReviews(
            @PathVariable Long productId,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        try {
            Map<String, Object> result = reviewsService.getProductReviews(productId, page, pageSize);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

//    @PostMapping("/reviews")
//    public Result<Map<String, Object>> submitReview(@Validated @RequestBody ReviewDTO reviewDTO) {
//        try {
//            Map<String, Object> result = reviewsService.submitReview(reviewDTO);
//            return Result.success(result);
//        } catch (Exception e) {
//            return Result.error(e.getMessage());
//        }
//    }

    @PostMapping("/merchant/products")
    public Result<Map<String, Object>> createProduct(@RequestBody Products product) {
        try {
            Map<String, Object> result = productsService.createProduct(product);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/merchant/products")
    public Result<Map<String, Object>> getMerchantProducts(
            @RequestParam String merchantAddress,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        try {
            Map<String, Object> result = productsService.getMerchantProducts(merchantAddress, page, pageSize);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
}