package com.lwf.controller;

import com.lwf.entity.dto.OrderDTO;
import com.lwf.service.IOrdersService;
import com.lwf.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class OrdersController {

    @Autowired
    private IOrdersService ordersService;

    @PostMapping("/orders")
    public Result<Map<String, Object>> createOrder(@Validated @RequestBody OrderDTO orderDTO) {
        try {
            Map<String, Object> result = ordersService.createOrder(orderDTO);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/orders/user")
    public Result<Map<String, Object>> getUserOrders(
            @RequestParam String userAddress,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        try {
            Map<String, Object> result = ordersService.getUserOrders(userAddress, page, pageSize);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/orders/merchant")
    public Result<Map<String, Object>> getMerchantOrders(
            @RequestParam Long merchantId,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        try {
            Map<String, Object> result = ordersService.getMerchantOrders(merchantId, page, pageSize);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @PutMapping("/orders/{orderId}/status")
    public Result<Map<String, Object>> updateOrderStatus(
            @PathVariable String orderId,
            @RequestBody Map<String, String> request) {
        try {
            String status = request.get("status");
            if (status == null) {
                return Result.error("状态不能为空");
            }
            Map<String, Object> result = ordersService.updateOrderStatus(orderId, status);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @PutMapping("/orders/{orderId}/confirm")
    public Result<Map<String, Object>> confirmReceipt(
            @PathVariable String orderId,
            @RequestParam String userAddress) {
        try {
            Map<String, Object> result = ordersService.confirmReceipt(orderId, userAddress);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
}