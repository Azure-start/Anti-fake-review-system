package com.lwf.controller;

import com.lwf.entity.Users;
import com.lwf.service.IUsersService;
import com.lwf.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class UsersController {

    @Autowired
    private IUsersService usersService;

    @PostMapping("/merchant/shop/apply")
    public Result<Map<String, Object>> applyShop(@RequestBody Map<String, String> request) {
        try {
            String address = request.get("address");
            String shopName = request.get("shopName");
            String shopDescription = request.get("shopDescription");

            if (address == null || shopName == null) {
                return Result.error("参数不完整");
            }

            Map<String, Object> result = usersService.applyShop(address, shopName, shopDescription);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/merchant/shop/info")
    public Result<Users> getShopInfo(@RequestParam String address) {
        try {
            Users shopInfo = usersService.getShopInfo(address);
            return Result.success(shopInfo);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
}