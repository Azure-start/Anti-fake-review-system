package com.lwf.controller;

import com.lwf.entity.dto.ReviewDTO;
import com.lwf.service.IReviewsService;
import com.lwf.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/reviews")  // 修改为专门的评价路径
public class ReviewsController {

    @Autowired
    private IReviewsService reviewsService;

    @PostMapping
    public Result<Map<String, Object>> submitReview(@Validated @RequestBody ReviewDTO reviewDTO) {
        try {
            Map<String, Object> result = reviewsService.submitReview(reviewDTO);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/product/{productId}")
    public Result<Map<String, Object>> getProductReviews(
            @PathVariable Long productId,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        try {
            Map<String, Object> result = reviewsService.getProductReviews(productId, page, pageSize);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/user")
    public Result<Map<String, Object>> getUserReviews(
            @RequestParam String userAddress,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        try {
            Map<String, Object> result = reviewsService.getUserReviews(userAddress, page, pageSize);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @PostMapping("/{reviewId}/vote")
    public Result<Map<String, Object>> voteReview(
            @PathVariable Long reviewId,
            @RequestParam String userAddress,
            @RequestParam Boolean isHelpful) {
        try {
            Map<String, Object> result = reviewsService.voteReview(reviewId, userAddress, isHelpful);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
}